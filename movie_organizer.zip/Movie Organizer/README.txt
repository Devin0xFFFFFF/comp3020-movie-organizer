The data folder contains all the xml data files required to properly run this application.
Please make sure they are in the same folder.